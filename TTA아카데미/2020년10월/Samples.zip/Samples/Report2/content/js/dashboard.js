/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "KO",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "OK",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9982168330955777, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "02_\uB85C\uADF8\uC778"], "isController": true}, {"data": [1.0, 500, 1500, "\/konakart\/QuickSearch.action-29"], "isController": false}, {"data": [0.99375, 500, 1500, "\/konakart\/Welcome.action-24"], "isController": false}, {"data": [1.0, 500, 1500, "06_\uCE74\uD2B8\uB2F4\uAE30"], "isController": true}, {"data": [1.0, 500, 1500, "\/konakart\/Welcom.action-28"], "isController": false}, {"data": [1.0, 500, 1500, "07_\uCE74\uD2B8\uBCF4\uAE30"], "isController": true}, {"data": [0.9875, 500, 1500, "\/konakart-23"], "isController": false}, {"data": [1.0, 500, 1500, "05_\uC0C1\uD488\uC0C1\uC138"], "isController": true}, {"data": [1.0, 500, 1500, "03_\uBA54\uC778"], "isController": true}, {"data": [1.0, 500, 1500, "\/konakart\/AddToCartOrWishListFromPost.action-49"], "isController": false}, {"data": [1.0, 500, 1500, "\/konakart\/LogIn.action-25"], "isController": false}, {"data": [1.0, 500, 1500, "\/konakart\/LoginSubmit.action-26"], "isController": false}, {"data": [1.0, 500, 1500, "\/konakart\/SelectProd.action-31"], "isController": false}, {"data": [1.0, 500, 1500, "08_\uB85C\uADF8\uC544\uC6C3"], "isController": true}, {"data": [1.0, 500, 1500, "\/konakart\/LogOut.action-52"], "isController": false}, {"data": [1.0, 500, 1500, "\/konakart\/ShowCartItems.action-51"], "isController": false}, {"data": [0.9875, 500, 1500, "01_\uCD08\uAE30\uC811\uC18D"], "isController": true}, {"data": [1.0, 500, 1500, "04_\uC0C1\uD488\uAC80\uC0C9"], "isController": true}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 7810, 0, 0.0, 53.47784891165165, 8, 2598, 34.0, 97.0, 124.0, 245.89000000000033, 52.01084169657901, 1219.9687114476296, 38.14814286832134], "isController": false}, "titles": ["Label", "#Samples", "KO", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions\/s", "Received", "Sent"], "items": [{"data": ["02_\uB85C\uADF8\uC778", 798, 0, 0.0, 75.13533834586465, 30, 373, 58.0, 124.10000000000002, 174.14999999999986, 307.06999999999994, 5.479301560708326, 140.67453922884667, 4.041228976270093], "isController": true}, {"data": ["\/konakart\/QuickSearch.action-29", 780, 0, 0.0, 35.688461538461524, 17, 193, 28.0, 53.0, 83.0, 150.18999999999994, 5.477181919682042, 174.7028475201708, 3.9581197466452265], "isController": false}, {"data": ["\/konakart\/Welcome.action-24", 800, 0, 0.0, 42.368749999999984, 17, 857, 26.0, 55.0, 81.94999999999993, 819.98, 5.4354103395093185, 116.25421775103104, 5.192236769022238], "isController": false}, {"data": ["06_\uCE74\uD2B8\uB2F4\uAE30", 762, 0, 0.0, 29.064304461942267, 12, 270, 24.0, 46.0, 58.0, 108.85000000000002, 5.400119057743006, 7.978886849965983, 3.754770282336933], "isController": true}, {"data": ["\/konakart\/Welcom.action-28", 784, 0, 0.0, 40.05867346938778, 17, 253, 33.0, 62.0, 78.75, 155.29999999999995, 5.424516878965467, 221.80639893204824, 2.945343149125781], "isController": false}, {"data": ["07_\uCE74\uD2B8\uBCF4\uAE30", 756, 0, 0.0, 42.284391534391574, 19, 193, 35.0, 66.0, 92.14999999999998, 147.8599999999999, 5.411789971008268, 156.55146591681878, 3.1604007838505317], "isController": true}, {"data": ["\/konakart-23", 800, 0, 0.0, 108.45750000000005, 44, 2598, 66.0, 113.0, 152.89999999999986, 2592.99, 5.34220138763681, 3.083243183684917, 4.91375579294963], "isController": false}, {"data": ["05_\uC0C1\uD488\uC0C1\uC138", 779, 0, 0.0, 111.09756097560984, 67, 406, 94.0, 170.0, 224.0, 320.60000000000014, 5.473503745028879, 225.10853195131463, 6.232524772171555], "isController": true}, {"data": ["03_\uBA54\uC778", 784, 0, 0.0, 40.05867346938778, 17, 253, 33.0, 62.0, 78.75, 155.29999999999995, 5.424479346848405, 221.80486425828548, 2.945322770359095], "isController": true}, {"data": ["\/konakart\/AddToCartOrWishListFromPost.action-49", 762, 0, 0.0, 29.064304461942267, 12, 270, 24.0, 46.0, 58.0, 108.85000000000002, 5.400119057743006, 7.978886849965983, 3.754770282336933], "isController": false}, {"data": ["\/konakart\/LogIn.action-25", 800, 0, 0.0, 15.906249999999988, 8, 193, 12.0, 23.0, 37.0, 67.98000000000002, 5.465488853818669, 122.49859813413335, 2.615321814815574], "isController": false}, {"data": ["\/konakart\/LoginSubmit.action-26", 798, 0, 0.0, 75.13533834586465, 30, 373, 58.0, 124.10000000000002, 174.14999999999986, 307.06999999999994, 5.479301560708326, 140.67453922884667, 4.041228976270093], "isController": false}, {"data": ["\/konakart\/SelectProd.action-31", 779, 0, 0.0, 111.09756097560984, 67, 406, 94.0, 170.0, 224.0, 320.60000000000014, 5.473503745028879, 225.10853195131463, 6.232524772171555], "isController": false}, {"data": ["08_\uB85C\uADF8\uC544\uC6C3", 751, 0, 0.0, 32.511318242343506, 17, 265, 26.0, 48.0, 63.0, 154.20000000000027, 5.418040415262857, 109.88463217204985, 2.9524087419108156], "isController": true}, {"data": ["\/konakart\/LogOut.action-52", 751, 0, 0.0, 32.511318242343506, 17, 265, 26.0, 48.0, 63.0, 154.20000000000027, 5.418079503643315, 109.88542493326598, 2.9524300420243845], "isController": false}, {"data": ["\/konakart\/ShowCartItems.action-51", 756, 0, 0.0, 42.284391534391574, 19, 193, 35.0, 66.0, 92.14999999999998, 147.8599999999999, 5.4118287113261845, 156.55258659104902, 3.1604234075908773], "isController": false}, {"data": ["01_\uCD08\uAE30\uC811\uC18D", 800, 0, 0.0, 166.73250000000004, 72, 3459, 106.0, 195.69999999999993, 263.89999999999986, 3448.99, 5.336535254486025, 236.82776723325662, 12.559944821059302], "isController": true}, {"data": ["04_\uC0C1\uD488\uAC80\uC0C9", 780, 0, 0.0, 35.688461538461524, 17, 193, 28.0, 53.0, 83.0, 150.18999999999994, 5.477143459026753, 174.7016207604803, 3.9580919528123024], "isController": true}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 7810, 0, null, null, null, null, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
