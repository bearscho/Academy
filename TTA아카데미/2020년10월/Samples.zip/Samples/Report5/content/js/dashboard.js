/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "KO",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "OK",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9985835694050992, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "02_\uB85C\uADF8\uC778"], "isController": true}, {"data": [1.0, 500, 1500, "\/konakart\/QuickSearch.action-29"], "isController": false}, {"data": [1.0, 500, 1500, "\/konakart\/Welcome.action-24"], "isController": false}, {"data": [1.0, 500, 1500, "06_\uCE74\uD2B8\uB2F4\uAE30"], "isController": true}, {"data": [1.0, 500, 1500, "\/konakart\/Welcom.action-28"], "isController": false}, {"data": [1.0, 500, 1500, "07_\uCE74\uD2B8\uBCF4\uAE30"], "isController": true}, {"data": [0.9875311720698254, 500, 1500, "\/konakart-23"], "isController": false}, {"data": [1.0, 500, 1500, "05_\uC0C1\uD488\uC0C1\uC138"], "isController": true}, {"data": [1.0, 500, 1500, "03_\uBA54\uC778"], "isController": true}, {"data": [1.0, 500, 1500, "\/konakart\/AddToCartOrWishListFromPost.action-49"], "isController": false}, {"data": [1.0, 500, 1500, "\/konakart\/LogIn.action-25"], "isController": false}, {"data": [1.0, 500, 1500, "\/konakart\/LoginSubmit.action-26"], "isController": false}, {"data": [1.0, 500, 1500, "\/konakart\/SelectProd.action-31"], "isController": false}, {"data": [1.0, 500, 1500, "08_\uB85C\uADF8\uC544\uC6C3"], "isController": true}, {"data": [1.0, 500, 1500, "\/konakart\/LogOut.action-52"], "isController": false}, {"data": [1.0, 500, 1500, "\/konakart\/ShowCartItems.action-51"], "isController": false}, {"data": [0.9875311720698254, 500, 1500, "01_\uCD08\uAE30\uC811\uC18D"], "isController": true}, {"data": [1.0, 500, 1500, "04_\uC0C1\uD488\uAC80\uC0C9"], "isController": true}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 7862, 0, 0.0, 45.174383108623694, 8, 2839, 29.0, 85.0, 102.0, 149.3699999999999, 52.37841439040639, 1228.682265208611, 38.38444942954697], "isController": false}, "titles": ["Label", "#Samples", "KO", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions\/s", "Received", "Sent"], "items": [{"data": ["02_\uB85C\uADF8\uC778", 800, 0, 0.0, 66.87625000000004, 27, 259, 54.0, 118.0, 139.0, 187.99, 5.510970275204078, 141.48599492387973, 4.064609668308477], "isController": true}, {"data": ["\/konakart\/QuickSearch.action-29", 783, 0, 0.0, 26.467432950191576, 16, 111, 25.0, 34.0, 39.0, 55.319999999999936, 5.446804958470721, 173.73392925153388, 3.936167645769857], "isController": false}, {"data": ["\/konakart\/Welcome.action-24", 802, 0, 0.0, 28.67581047381545, 16, 169, 24.0, 34.0, 54.84999999999991, 149.97000000000003, 5.4464455491266675, 116.49015431454241, 5.202828845278842], "isController": false}, {"data": ["06_\uCE74\uD2B8\uB2F4\uAE30", 773, 0, 0.0, 25.309184993531666, 12, 98, 21.0, 39.60000000000002, 50.0, 73.51999999999998, 5.468075774938812, 8.079295554182051, 3.802021437262142], "isController": true}, {"data": ["\/konakart\/Welcom.action-28", 799, 0, 0.0, 32.41927409261581, 18, 149, 28.0, 45.0, 62.0, 103.0, 5.523792404958278, 225.8678131070814, 2.99924665737969], "isController": false}, {"data": ["07_\uCE74\uD2B8\uBCF4\uAE30", 761, 0, 0.0, 33.97634691195797, 20, 133, 30.0, 49.0, 57.0, 78.0, 5.417758286820822, 156.72263138820267, 3.163886187030129], "isController": true}, {"data": ["\/konakart-23", 802, 0, 0.0, 101.96508728179566, 43, 2839, 64.0, 87.70000000000005, 104.0, 2836.0, 5.344279555132041, 3.0844425948076526, 4.915838113142796], "isController": false}, {"data": ["05_\uC0C1\uD488\uC0C1\uC138", 780, 0, 0.0, 94.49487179487181, 59, 249, 88.0, 122.89999999999998, 137.0, 205.75999999999976, 5.487586095301078, 225.68769611084923, 6.248559948360407], "isController": true}, {"data": ["03_\uBA54\uC778", 799, 0, 0.0, 32.41927409261581, 18, 149, 28.0, 45.0, 62.0, 103.0, 5.523792404958278, 225.8678131070814, 2.99924665737969], "isController": true}, {"data": ["\/konakart\/AddToCartOrWishListFromPost.action-49", 773, 0, 0.0, 25.30918499353167, 12, 98, 21.0, 39.60000000000002, 50.0, 73.51999999999998, 5.468114455487568, 8.079352706203798, 3.802048332331199], "isController": false}, {"data": ["\/konakart\/LogIn.action-25", 802, 0, 0.0, 12.25685785536158, 8, 61, 11.0, 15.0, 18.0, 39.97000000000003, 5.4512581395032695, 122.17931137720734, 2.6085121956607438], "isController": false}, {"data": ["\/konakart\/LoginSubmit.action-26", 800, 0, 0.0, 66.87625000000004, 27, 259, 54.0, 118.0, 139.0, 187.99, 5.510970275204078, 141.48599492387973, 4.064609668308477], "isController": false}, {"data": ["\/konakart\/SelectProd.action-31", 780, 0, 0.0, 94.49487179487181, 59, 249, 88.0, 122.89999999999998, 137.0, 205.75999999999976, 5.487547488391726, 225.68610832629804, 6.248515987758548], "isController": false}, {"data": ["08_\uB85C\uADF8\uC544\uC6C3", 760, 0, 0.0, 28.03026315789472, 16, 105, 25.0, 38.0, 49.0, 73.38999999999999, 5.470774546501584, 110.95414627123526, 2.981144723581918], "isController": true}, {"data": ["\/konakart\/LogOut.action-52", 760, 0, 0.0, 28.03026315789472, 16, 105, 25.0, 38.0, 49.0, 73.38999999999999, 5.470813927540509, 110.95494496793094, 2.981166183171488], "isController": false}, {"data": ["\/konakart\/ShowCartItems.action-51", 761, 0, 0.0, 33.97634691195797, 20, 133, 30.0, 49.0, 57.0, 78.0, 5.4177968575354365, 156.72374714560064, 3.163908711724796], "isController": false}, {"data": ["01_\uCD08\uAE30\uC811\uC18D", 802, 0, 0.0, 142.8977556109724, 73, 3036, 100.0, 131.0, 184.54999999999973, 3026.9700000000003, 5.339725024135291, 236.96891306925997, 12.567672442491428], "isController": true}, {"data": ["04_\uC0C1\uD488\uAC80\uC0C9", 783, 0, 0.0, 26.467432950191576, 16, 111, 25.0, 34.0, 39.0, 55.319999999999936, 5.446767068971514, 173.73272070971444, 3.9361402646864456], "isController": true}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 7862, 0, null, null, null, null, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
