/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "KO",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "OK",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9975, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "02_\uB85C\uADF8\uC778"], "isController": true}, {"data": [1.0, 500, 1500, "\/konakart\/QuickSearch.action-29"], "isController": false}, {"data": [1.0, 500, 1500, "\/konakart\/Welcome.action-24"], "isController": false}, {"data": [1.0, 500, 1500, "06_\uCE74\uD2B8\uB2F4\uAE30"], "isController": true}, {"data": [1.0, 500, 1500, "\/konakart\/Welcom.action-28"], "isController": false}, {"data": [1.0, 500, 1500, "07_\uCE74\uD2B8\uBCF4\uAE30"], "isController": true}, {"data": [0.9782608695652174, 500, 1500, "\/konakart-23"], "isController": false}, {"data": [1.0, 500, 1500, "05_\uC0C1\uD488\uC0C1\uC138"], "isController": true}, {"data": [1.0, 500, 1500, "03_\uBA54\uC778"], "isController": true}, {"data": [1.0, 500, 1500, "\/konakart\/AddToCartOrWishListFromPost.action-49"], "isController": false}, {"data": [1.0, 500, 1500, "\/konakart\/LogIn.action-25"], "isController": false}, {"data": [1.0, 500, 1500, "\/konakart\/LoginSubmit.action-26"], "isController": false}, {"data": [1.0, 500, 1500, "\/konakart\/SelectProd.action-31"], "isController": false}, {"data": [1.0, 500, 1500, "08_\uB85C\uADF8\uC544\uC6C3"], "isController": true}, {"data": [1.0, 500, 1500, "\/konakart\/LogOut.action-52"], "isController": false}, {"data": [1.0, 500, 1500, "\/konakart\/ShowCartItems.action-51"], "isController": false}, {"data": [0.9782608695652174, 500, 1500, "01_\uCD08\uAE30\uC811\uC18D"], "isController": true}, {"data": [1.0, 500, 1500, "04_\uC0C1\uD488\uAC80\uC0C9"], "isController": true}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 4460, 0, 0.0, 48.34506726457387, 7, 2693, 30.0, 88.0, 103.0, 141.39000000000033, 49.53299052653791, 1162.340584775269, 36.26159497825991], "isController": false}, "titles": ["Label", "#Samples", "KO", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions\/s", "Received", "Sent"], "items": [{"data": ["02_\uB85C\uADF8\uC778", 459, 0, 0.0, 67.47058823529413, 29, 204, 57.0, 119.0, 134.0, 160.39999999999986, 5.325938130932213, 136.73016071729015, 3.921377415672646], "isController": true}, {"data": ["\/konakart\/QuickSearch.action-29", 450, 0, 0.0, 28.113333333333323, 17, 114, 25.0, 37.0, 48.0, 81.92000000000007, 5.396783517023854, 172.13842112600892, 3.9000193384742694], "isController": false}, {"data": ["\/konakart\/Welcome.action-24", 460, 0, 0.0, 30.184782608695645, 16, 122, 25.0, 45.900000000000034, 77.89999999999998, 94.38999999999999, 5.302104705041611, 113.42839060951152, 5.050304258685078], "isController": false}, {"data": ["06_\uCE74\uD2B8\uB2F4\uAE30", 430, 0, 0.0, 24.676744186046495, 13, 83, 22.0, 36.0, 45.0, 64.07, 5.370435130139382, 7.935027687403207, 3.7341306764250386], "isController": true}, {"data": ["\/konakart\/Welcom.action-28", 450, 0, 0.0, 33.63333333333334, 18, 130, 29.0, 48.900000000000034, 61.44999999999999, 97.92000000000007, 5.393807908521017, 220.55289902192283, 2.9286691378297713], "isController": false}, {"data": ["07_\uCE74\uD2B8\uBCF4\uAE30", 430, 0, 0.0, 35.497674418604674, 19, 110, 31.0, 53.0, 62.44999999999999, 101.07, 5.371844041625545, 155.39475294592552, 3.137072985246168], "isController": true}, {"data": ["\/konakart-23", 460, 0, 0.0, 126.88043478260867, 45, 2693, 66.0, 95.90000000000003, 112.89999999999998, 2690.0, 5.144378089422712, 2.969069776219553, 4.6830615759690435], "isController": false}, {"data": ["05_\uC0C1\uD488\uC0C1\uC138", 440, 0, 0.0, 94.74545454545454, 62, 207, 89.5, 122.0, 134.0, 167.3599999999999, 5.3116361046392315, 218.45140909255525, 6.048210642587249], "isController": true}, {"data": ["03_\uBA54\uC778", 450, 0, 0.0, 33.63333333333334, 18, 130, 29.0, 48.900000000000034, 61.44999999999999, 97.92000000000007, 5.393872560770965, 220.5555426535456, 2.9287042419811096], "isController": true}, {"data": ["\/konakart\/AddToCartOrWishListFromPost.action-49", 430, 0, 0.0, 24.676744186046495, 13, 83, 22.0, 36.0, 45.0, 64.07, 5.370368057550363, 7.9349285850329085, 3.7340840400154867], "isController": false}, {"data": ["\/konakart\/LogIn.action-25", 460, 0, 0.0, 12.52826086956522, 7, 39, 11.0, 17.0, 20.94999999999999, 34.389999999999986, 5.3068758652515, 118.89598865799492, 2.539423021458237], "isController": false}, {"data": ["\/konakart\/LoginSubmit.action-26", 459, 0, 0.0, 67.47058823529413, 29, 204, 57.0, 119.0, 134.0, 160.39999999999986, 5.325938130932213, 136.73016071729015, 3.921377415672646], "isController": false}, {"data": ["\/konakart\/SelectProd.action-31", 440, 0, 0.0, 94.74545454545454, 62, 207, 89.5, 122.0, 134.0, 167.3599999999999, 5.3116361046392315, 218.45140909255525, 6.048210642587249], "isController": false}, {"data": ["08_\uB85C\uADF8\uC544\uC6C3", 421, 0, 0.0, 26.81235154394298, 16, 55, 25.0, 38.0, 44.0, 52.0, 5.29340022380647, 107.35677328907498, 2.8844895750820414], "isController": true}, {"data": ["\/konakart\/LogOut.action-52", 421, 0, 0.0, 26.81235154394298, 16, 55, 25.0, 38.0, 44.0, 52.0, 5.293466780666901, 107.3581231454006, 2.8845258433712218], "isController": false}, {"data": ["\/konakart\/ShowCartItems.action-51", 430, 0, 0.0, 35.497674418604674, 19, 110, 31.0, 53.0, 62.44999999999999, 101.07, 5.371844041625545, 155.39475294592552, 3.137072985246168], "isController": false}, {"data": ["01_\uCD08\uAE30\uC811\uC18D", 460, 0, 0.0, 169.59347826086955, 71, 2819, 102.0, 154.90000000000003, 195.95, 2813.7799999999997, 5.134673557547412, 227.84793430547958, 12.022073340719077], "isController": true}, {"data": ["04_\uC0C1\uD488\uAC80\uC0C9", 450, 0, 0.0, 28.113333333333323, 17, 114, 25.0, 37.0, 48.0, 81.92000000000007, 5.396783517023854, 172.13842112600892, 3.9000193384742694], "isController": true}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 4460, 0, null, null, null, null, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
