/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "KO",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "OK",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9983687943262411, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "02_\uB85C\uADF8\uC778"], "isController": true}, {"data": [1.0, 500, 1500, "\/konakart\/QuickSearch.action-29"], "isController": false}, {"data": [1.0, 500, 1500, "\/konakart\/Welcome.action-24"], "isController": false}, {"data": [1.0, 500, 1500, "06_\uCE74\uD2B8\uB2F4\uAE30"], "isController": true}, {"data": [0.9993686868686869, 500, 1500, "\/konakart\/Welcom.action-28"], "isController": false}, {"data": [1.0, 500, 1500, "07_\uCE74\uD2B8\uBCF4\uAE30"], "isController": true}, {"data": [0.9862671660424469, 500, 1500, "\/konakart-23"], "isController": false}, {"data": [1.0, 500, 1500, "05_\uC0C1\uD488\uC0C1\uC138"], "isController": true}, {"data": [0.9993686868686869, 500, 1500, "03_\uBA54\uC778"], "isController": true}, {"data": [1.0, 500, 1500, "\/konakart\/AddToCartOrWishListFromPost.action-49"], "isController": false}, {"data": [1.0, 500, 1500, "\/konakart\/LogIn.action-25"], "isController": false}, {"data": [1.0, 500, 1500, "\/konakart\/LoginSubmit.action-26"], "isController": false}, {"data": [1.0, 500, 1500, "\/konakart\/SelectProd.action-31"], "isController": false}, {"data": [1.0, 500, 1500, "08_\uB85C\uADF8\uC544\uC6C3"], "isController": true}, {"data": [1.0, 500, 1500, "\/konakart\/LogOut.action-52"], "isController": false}, {"data": [1.0, 500, 1500, "\/konakart\/ShowCartItems.action-51"], "isController": false}, {"data": [0.9862671660424469, 500, 1500, "01_\uCD08\uAE30\uC811\uC18D"], "isController": true}, {"data": [1.0, 500, 1500, "04_\uC0C1\uD488\uAC80\uC0C9"], "isController": true}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 7851, 0, 0.0, 47.40185963571525, 8, 2456, 30.0, 89.0, 109.0, 172.0, 52.275874926756515, 1225.4202293103792, 38.31623442951646], "isController": false}, "titles": ["Label", "#Samples", "KO", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions\/s", "Received", "Sent"], "items": [{"data": ["02_\uB85C\uADF8\uC778", 800, 0, 0.0, 67.71000000000012, 30, 244, 55.0, 120.0, 146.94999999999993, 202.96000000000004, 5.4691505725517, 140.41199554563323, 4.033765595624679], "isController": true}, {"data": ["\/konakart\/QuickSearch.action-29", 780, 0, 0.0, 27.579487179487188, 16, 114, 25.0, 35.0, 42.94999999999993, 66.18999999999994, 5.476951163852123, 174.6954872204473, 3.9579529895025103], "isController": false}, {"data": ["\/konakart\/Welcome.action-24", 801, 0, 0.0, 29.13108614232212, 16, 128, 25.0, 37.0, 57.0, 111.0, 5.427638265866186, 116.08794242493799, 5.1848376367073685], "isController": false}, {"data": ["06_\uCE74\uD2B8\uB2F4\uAE30", 774, 0, 0.0, 28.70284237726099, 12, 396, 22.0, 43.0, 53.0, 126.75, 5.444569499155881, 8.044564113498875, 3.7856772298818235], "isController": true}, {"data": ["\/konakart\/Welcom.action-28", 792, 0, 0.0, 36.03156565656562, 19, 501, 29.0, 47.0, 66.0, 148.41999999999325, 5.445844105836405, 222.68254557972114, 2.9569231668408604], "isController": false}, {"data": ["07_\uCE74\uD2B8\uBCF4\uAE30", 763, 0, 0.0, 38.93840104849278, 19, 374, 32.0, 54.60000000000002, 74.79999999999995, 154.5200000000001, 5.406707718907888, 156.40530638379474, 3.157432828034098], "isController": true}, {"data": ["\/konakart-23", 801, 0, 0.0, 102.89762796504375, 42, 2456, 66.0, 98.0, 118.0, 2443.0, 5.34, 3.08197265625, 4.91181640625], "isController": false}, {"data": ["05_\uC0C1\uD488\uC0C1\uC138", 780, 0, 0.0, 100.36666666666675, 63, 401, 92.5, 133.89999999999998, 151.0, 249.2799999999993, 5.471111828122917, 225.01015969684428, 6.2298011636634], "isController": true}, {"data": ["03_\uBA54\uC778", 792, 0, 0.0, 36.03156565656562, 19, 501, 29.0, 47.0, 66.0, 148.41999999999325, 5.445844105836405, 222.68254557972114, 2.9569231668408604], "isController": true}, {"data": ["\/konakart\/AddToCartOrWishListFromPost.action-49", 774, 0, 0.0, 28.70284237726099, 12, 396, 22.0, 43.0, 53.0, 126.75, 5.444531200540233, 8.044507525798215, 3.7856506003756305], "isController": false}, {"data": ["\/konakart\/LogIn.action-25", 801, 0, 0.0, 13.00374531835206, 8, 83, 11.0, 17.800000000000068, 22.0, 35.98000000000002, 5.430582109587927, 121.71567315743265, 2.5986183922832855], "isController": false}, {"data": ["\/konakart\/LoginSubmit.action-26", 800, 0, 0.0, 67.71000000000012, 30, 244, 55.0, 120.0, 146.94999999999993, 202.96000000000004, 5.4691505725517, 140.41199554563323, 4.033765595624679], "isController": false}, {"data": ["\/konakart\/SelectProd.action-31", 780, 0, 0.0, 100.36666666666675, 63, 401, 92.5, 133.89999999999998, 151.0, 249.2799999999993, 5.471111828122917, 225.01015969684428, 6.2298011636634], "isController": false}, {"data": ["08_\uB85C\uADF8\uC544\uC6C3", 759, 0, 0.0, 28.39525691699605, 15, 300, 25.0, 39.0, 48.0, 69.59999999999991, 5.420344502528065, 109.93136194189734, 2.953664289463536], "isController": true}, {"data": ["\/konakart\/LogOut.action-52", 759, 0, 0.0, 28.39525691699605, 15, 300, 25.0, 39.0, 48.0, 69.59999999999991, 5.420383211809151, 109.93214701450435, 2.953685382997565], "isController": false}, {"data": ["\/konakart\/ShowCartItems.action-51", 763, 0, 0.0, 38.93840104849278, 19, 374, 32.0, 54.60000000000002, 74.79999999999995, 154.5200000000001, 5.406746031746032, 156.40641469804066, 3.1574552021329363], "isController": false}, {"data": ["01_\uCD08\uAE30\uC811\uC18D", 801, 0, 0.0, 145.0324594257178, 74, 2572, 104.0, 150.80000000000007, 192.79999999999995, 2568.0, 5.335091715621628, 236.7631154338009, 12.556657510507], "isController": true}, {"data": ["04_\uC0C1\uD488\uAC80\uC0C9", 780, 0, 0.0, 27.579487179487188, 16, 114, 25.0, 35.0, 42.94999999999993, 66.18999999999994, 5.476951163852123, 174.6954872204473, 3.9579529895025103], "isController": true}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 7851, 0, null, null, null, null, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
